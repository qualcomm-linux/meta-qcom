Customers must specify an appropriate outbound license in the recipes to build the proprietary sources.
Customers should consult their own legal team for guidance on outbound licensing decisions.
The chosen outbound license must be compatible with the PKLA.